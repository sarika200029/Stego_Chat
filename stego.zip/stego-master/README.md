# stegoChat
<h2>Live website: <a href='https://stegochat.herokuapp.com' target="_blank">stegochat.herokuapp.com</a></h2>

<h5>To Run Locally:</h5>
<ol>
  <l1>1.<a href='https://www.python.org/downloads/' target="_blank">Install Python</a></li><br>
  <l1>2.<a href='https://www.liquidweb.com/kb/install-pip-windows/' target="_blank">pip</a> install requirements.txt</li><br>
  <l1>3.<a href='https://flask.palletsprojects.com/en/1.1.x/quickstart/' target="_blank">Run flask app</a> app.py from command window</li><br>
</ol>
  
